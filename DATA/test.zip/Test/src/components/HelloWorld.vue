<script setup>
import { ref } from 'vue'

defineProps({
  msg: String,
})

const count = ref(0)

const test = () => {


  fetch('http://localhost:60287/person/login', {
    method: 'POST',
    headers: {
      'Accept': 'application/json, text/plain, */*',
      'Accept-Language': 'en-US,en;q=0.9,fa;q=0.8',
      'Content-Type': 'application/json;charset=UTF-8',
      'Origin': 'http://pelekan.sepehrdata.com',
      'Referer': 'http://pelekan.sepehrdata.com/',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36'
    },
    body: JSON.stringify({
      username: 'rahbar',
      password: '123456'
    })
  })
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(data => {
      console.log(data);
    })
    .catch(error => {
      console.error('There was a problem with your fetch operation:', error);
    });
}
</script>

<template>
  <h1>{{ msg }}</h1>

  <div class="card">
    <button type="button" @click="count++">count is {{ count }}</button>
    <p>
      Edit
      <code>components/HelloWorld.vue</code> to test HMR
    </p>
  </div>

  <button @click="test">
    Test cUrl
  </button>
</template>

<style scoped>
.read-the-docs {
  color: #888;
}
</style>
